return {
  version = "1.9",
  luaversion = "5.1",
  tiledversion = "1.9.2",
  class = "",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 100,
  height = 30,
  tilewidth = 70,
  tileheight = 70,
  nextlayerid = 6,
  nextobjectid = 1,
  properties = {},
  tilesets = {
    {
      name = "PT",
      firstgid = 1,
      class = "",
      tilewidth = 70,
      tileheight = 146,
      spacing = 0,
      margin = 0,
      columns = 0,
      objectalignment = "unspecified",
      tilerendersize = "tile",
      fillmode = "stretch",
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      wangsets = {},
      tilecount = 172,
      tiles = {
        {
          id = 0,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/box.png",
          width = 70,
          height = 70
        },
        {
          id = 1,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 2,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxCoin.png",
          width = 70,
          height = 70
        },
        {
          id = 3,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxCoin_disabled.png",
          width = 70,
          height = 70
        },
        {
          id = 4,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxCoinAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 5,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxCoinAlt_disabled.png",
          width = 70,
          height = 70
        },
        {
          id = 6,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxEmpty.png",
          width = 70,
          height = 70
        },
        {
          id = 7,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxExplosive.png",
          width = 70,
          height = 70
        },
        {
          id = 8,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxExplosive_disabled.png",
          width = 70,
          height = 70
        },
        {
          id = 9,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxExplosiveAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 10,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxItem.png",
          width = 70,
          height = 70
        },
        {
          id = 11,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxItem_disabled.png",
          width = 70,
          height = 70
        },
        {
          id = 12,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxItemAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 13,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxItemAlt_disabled.png",
          width = 70,
          height = 70
        },
        {
          id = 14,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/boxWarning.png",
          width = 70,
          height = 70
        },
        {
          id = 15,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/brickWall.png",
          width = 70,
          height = 70
        },
        {
          id = 16,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/bridge.png",
          width = 70,
          height = 70
        },
        {
          id = 17,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/bridgeLogs.png",
          width = 70,
          height = 70
        },
        {
          id = 18,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castle.png",
          width = 70,
          height = 70
        },
        {
          id = 19,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 20,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 21,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 22,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 23,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 24,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 25,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 26,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 27,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 28,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 29,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 30,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 31,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 32,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 33,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleLedgeLeft.png",
          width = 5,
          height = 22
        },
        {
          id = 34,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleLedgeRight.png",
          width = 5,
          height = 22
        },
        {
          id = 35,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 36,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleMid.png",
          width = 70,
          height = 70
        },
        {
          id = 37,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/castleRight.png",
          width = 70,
          height = 70
        },
        {
          id = 38,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirt.png",
          width = 70,
          height = 70
        },
        {
          id = 39,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 40,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 41,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 42,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 43,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 44,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 45,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 46,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 47,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 48,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 49,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 50,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 51,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 52,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 53,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtLedgeLeft.png",
          width = 5,
          height = 18
        },
        {
          id = 54,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtLedgeRight.png",
          width = 5,
          height = 18
        },
        {
          id = 55,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 56,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtMid.png",
          width = 70,
          height = 70
        },
        {
          id = 57,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/dirtRight.png",
          width = 70,
          height = 70
        },
        {
          id = 58,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/door_closedMid.png",
          width = 70,
          height = 70
        },
        {
          id = 59,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/door_closedTop.png",
          width = 70,
          height = 70
        },
        {
          id = 60,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/door_openMid.png",
          width = 70,
          height = 70
        },
        {
          id = 61,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/door_openTop.png",
          width = 70,
          height = 70
        },
        {
          id = 62,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/fence.png",
          width = 70,
          height = 70
        },
        {
          id = 63,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/fenceBroken.png",
          width = 70,
          height = 70
        },
        {
          id = 64,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grass.png",
          width = 70,
          height = 70
        },
        {
          id = 65,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 66,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 67,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 68,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 69,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 70,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 71,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 72,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 73,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 74,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 75,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 76,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 77,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 78,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 79,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassLedgeLeft.png",
          width = 5,
          height = 24
        },
        {
          id = 80,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassLedgeRight.png",
          width = 5,
          height = 24
        },
        {
          id = 81,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 82,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassMid.png",
          width = 70,
          height = 70
        },
        {
          id = 83,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/grassRight.png",
          width = 70,
          height = 70
        },
        {
          id = 84,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/hill_large.png",
          width = 48,
          height = 146
        },
        {
          id = 85,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/hill_largeAlt.png",
          width = 48,
          height = 146
        },
        {
          id = 86,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/hill_small.png",
          width = 48,
          height = 106
        },
        {
          id = 87,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/hill_smallAlt.png",
          width = 48,
          height = 106
        },
        {
          id = 88,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/ladder_mid.png",
          width = 70,
          height = 70
        },
        {
          id = 89,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/ladder_top.png",
          width = 70,
          height = 70
        },
        {
          id = 90,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/liquidLava.png",
          width = 70,
          height = 70
        },
        {
          id = 91,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/liquidLavaTop.png",
          width = 70,
          height = 70
        },
        {
          id = 92,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/liquidLavaTop_mid.png",
          width = 70,
          height = 70
        },
        {
          id = 93,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/liquidWater.png",
          width = 70,
          height = 70
        },
        {
          id = 94,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/liquidWaterTop.png",
          width = 70,
          height = 70
        },
        {
          id = 95,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/liquidWaterTop_mid.png",
          width = 70,
          height = 70
        },
        {
          id = 172,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/lock_blue.png",
          width = 70,
          height = 70
        },
        {
          id = 173,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/lock_green.png",
          width = 70,
          height = 70
        },
        {
          id = 174,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/lock_red.png",
          width = 70,
          height = 70
        },
        {
          id = 175,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/lock_yellow.png",
          width = 70,
          height = 70
        },
        {
          id = 176,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/rockHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 177,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/rockHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 178,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/ropeAttached.png",
          width = 70,
          height = 70
        },
        {
          id = 179,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/ropeHorizontal.png",
          width = 70,
          height = 70
        },
        {
          id = 180,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/ropeVertical.png",
          width = 70,
          height = 70
        },
        {
          id = 181,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sand.png",
          width = 70,
          height = 70
        },
        {
          id = 182,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 183,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 184,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 185,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 186,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 187,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 188,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 189,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 190,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 191,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 192,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 193,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 194,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 195,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 196,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandLedgeLeft.png",
          width = 5,
          height = 18
        },
        {
          id = 197,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandLedgeRight.png",
          width = 5,
          height = 18
        },
        {
          id = 198,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 199,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandMid.png",
          width = 70,
          height = 70
        },
        {
          id = 200,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sandRight.png",
          width = 70,
          height = 70
        },
        {
          id = 125,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/sign.png",
          width = 70,
          height = 70
        },
        {
          id = 126,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/signExit.png",
          width = 70,
          height = 70
        },
        {
          id = 127,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/signLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 128,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/signRight.png",
          width = 70,
          height = 70
        },
        {
          id = 220,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowLedgeLeft.png",
          width = 5,
          height = 18
        },
        {
          id = 221,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowLedgeRight.png",
          width = 5,
          height = 18
        },
        {
          id = 222,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 223,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowMid.png",
          width = 70,
          height = 70
        },
        {
          id = 224,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowRight.png",
          width = 70,
          height = 70
        },
        {
          id = 225,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stone.png",
          width = 70,
          height = 70
        },
        {
          id = 226,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 227,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 228,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 229,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 230,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 231,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 232,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 233,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 234,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 235,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 236,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 237,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 238,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneLedgeLeft.png",
          width = 5,
          height = 24
        },
        {
          id = 239,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneLedgeRight.png",
          width = 5,
          height = 24
        },
        {
          id = 240,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 241,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneMid.png",
          width = 70,
          height = 70
        },
        {
          id = 242,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneRight.png",
          width = 70,
          height = 70
        },
        {
          id = 243,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/stoneWall.png",
          width = 70,
          height = 70
        },
        {
          id = 205,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snow.png",
          width = 70,
          height = 70
        },
        {
          id = 206,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 207,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 208,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 209,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 210,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 211,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 212,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 213,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 214,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 215,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 216,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 217,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 218,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 219,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/snowHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 168,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/tochLit.png",
          width = 70,
          height = 70
        },
        {
          id = 169,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/tochLit2.png",
          width = 70,
          height = 70
        },
        {
          id = 244,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/torch.png",
          width = 70,
          height = 70
        },
        {
          id = 245,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Tiles/window.png",
          width = 70,
          height = 70
        }
      }
    },
    {
      name = "PT Items",
      firstgid = 247,
      class = "",
      tilewidth = 129,
      tileheight = 71,
      spacing = 0,
      margin = 0,
      columns = 0,
      objectalignment = "unspecified",
      tilerendersize = "tile",
      fillmode = "stretch",
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      wangsets = {},
      tilecount = 59,
      tiles = {
        {
          id = 0,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/bomb.png",
          width = 70,
          height = 70
        },
        {
          id = 1,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/bombFlash.png",
          width = 70,
          height = 70
        },
        {
          id = 2,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/bush.png",
          width = 70,
          height = 70
        },
        {
          id = 3,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonBlue.png",
          width = 70,
          height = 70
        },
        {
          id = 4,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonBlue_pressed.png",
          width = 70,
          height = 70
        },
        {
          id = 5,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 6,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonGreen_pressed.png",
          width = 70,
          height = 70
        },
        {
          id = 7,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonRed.png",
          width = 70,
          height = 70
        },
        {
          id = 8,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonRed_pressed.png",
          width = 70,
          height = 70
        },
        {
          id = 9,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonYellow.png",
          width = 70,
          height = 70
        },
        {
          id = 10,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/buttonYellow_pressed.png",
          width = 70,
          height = 70
        },
        {
          id = 11,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/cactus.png",
          width = 70,
          height = 70
        },
        {
          id = 12,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/chain.png",
          width = 70,
          height = 70
        },
        {
          id = 13,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/cloud1.png",
          width = 128,
          height = 71
        },
        {
          id = 14,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/cloud2.png",
          width = 129,
          height = 71
        },
        {
          id = 15,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/cloud3.png",
          width = 129,
          height = 71
        },
        {
          id = 16,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/coinBronze.png",
          width = 70,
          height = 70
        },
        {
          id = 17,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/coinGold.png",
          width = 70,
          height = 70
        },
        {
          id = 18,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/coinSilver.png",
          width = 70,
          height = 70
        },
        {
          id = 19,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/fireball.png",
          width = 70,
          height = 70
        },
        {
          id = 20,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagBlue.png",
          width = 70,
          height = 70
        },
        {
          id = 21,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagBlue2.png",
          width = 70,
          height = 70
        },
        {
          id = 22,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagBlueHanging.png",
          width = 70,
          height = 70
        },
        {
          id = 23,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 24,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagGreen2.png",
          width = 70,
          height = 70
        },
        {
          id = 25,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagGreenHanging.png",
          width = 70,
          height = 70
        },
        {
          id = 26,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagRed.png",
          width = 70,
          height = 70
        },
        {
          id = 27,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagRed2.png",
          width = 70,
          height = 70
        },
        {
          id = 28,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagRedHanging.png",
          width = 70,
          height = 70
        },
        {
          id = 29,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagYellow.png",
          width = 70,
          height = 70
        },
        {
          id = 30,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagYellow2.png",
          width = 70,
          height = 70
        },
        {
          id = 31,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/flagYellowHanging.png",
          width = 70,
          height = 70
        },
        {
          id = 32,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/gemBlue.png",
          width = 70,
          height = 70
        },
        {
          id = 33,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/gemGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 34,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/gemRed.png",
          width = 70,
          height = 70
        },
        {
          id = 35,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/gemYellow.png",
          width = 70,
          height = 70
        },
        {
          id = 36,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/keyBlue.png",
          width = 70,
          height = 70
        },
        {
          id = 37,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/keyGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 38,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/keyRed.png",
          width = 70,
          height = 70
        },
        {
          id = 39,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/keyYellow.png",
          width = 70,
          height = 70
        },
        {
          id = 40,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/mushroomBrown.png",
          width = 70,
          height = 70
        },
        {
          id = 41,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/mushroomRed.png",
          width = 70,
          height = 70
        },
        {
          id = 42,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/particleBrick1a.png",
          width = 19,
          height = 14
        },
        {
          id = 43,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/particleBrick1b.png",
          width = 21,
          height = 21
        },
        {
          id = 44,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/particleBrick2a.png",
          width = 19,
          height = 14
        },
        {
          id = 45,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/particleBrick2b.png",
          width = 21,
          height = 21
        },
        {
          id = 46,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/plant.png",
          width = 70,
          height = 70
        },
        {
          id = 47,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/plantPurple.png",
          width = 70,
          height = 70
        },
        {
          id = 48,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/rock.png",
          width = 70,
          height = 70
        },
        {
          id = 49,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/snowhill.png",
          width = 70,
          height = 70
        },
        {
          id = 50,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/spikes.png",
          width = 70,
          height = 70
        },
        {
          id = 51,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/springboardDown.png",
          width = 70,
          height = 70
        },
        {
          id = 52,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/springboardUp.png",
          width = 70,
          height = 70
        },
        {
          id = 53,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/star.png",
          width = 70,
          height = 70
        },
        {
          id = 54,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/switchLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 55,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/switchMid.png",
          width = 70,
          height = 70
        },
        {
          id = 56,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/switchRight.png",
          width = 70,
          height = 70
        },
        {
          id = 57,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/weight.png",
          width = 70,
          height = 70
        },
        {
          id = 58,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Items/weightChained.png",
          width = 70,
          height = 70
        }
      }
    },
    {
      name = "PT Ice",
      firstgid = 365,
      class = "",
      tilewidth = 70,
      tileheight = 70,
      spacing = 0,
      margin = 0,
      columns = 0,
      objectalignment = "unspecified",
      tilerendersize = "tile",
      fillmode = "stretch",
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      wangsets = {},
      tilecount = 96,
      tiles = {
        {
          id = 191,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 192,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneGreenSmall.png",
          width = 70,
          height = 70
        },
        {
          id = 193,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneGreenTop.png",
          width = 70,
          height = 70
        },
        {
          id = 194,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneGreenTopAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 195,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneRed.png",
          width = 70,
          height = 70
        },
        {
          id = 196,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneRedSmall.png",
          width = 70,
          height = 70
        },
        {
          id = 197,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneRedTop.png",
          width = 70,
          height = 70
        },
        {
          id = 198,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/caneRedTopAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 199,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/deadTree.png",
          width = 70,
          height = 70
        },
        {
          id = 200,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceBlock.png",
          width = 70,
          height = 70
        },
        {
          id = 201,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceBlockAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 202,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceBlockHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 203,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceBlockHalfAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 204,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWater.png",
          width = 70,
          height = 70
        },
        {
          id = 205,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 206,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterDeep.png",
          width = 70,
          height = 70
        },
        {
          id = 207,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterDeepAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 208,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterDeepStars.png",
          width = 70,
          height = 70
        },
        {
          id = 209,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterDeepStarsAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 210,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterMid.png",
          width = 70,
          height = 70
        },
        {
          id = 211,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iceWaterMidAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 212,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/igloo.png",
          width = 70,
          height = 70
        },
        {
          id = 213,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iglooAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 214,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iglooDoor.png",
          width = 70,
          height = 70
        },
        {
          id = 215,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iglooRoof.png",
          width = 70,
          height = 70
        },
        {
          id = 216,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iglooRoofLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 217,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/iglooRoofRight.png",
          width = 70,
          height = 70
        },
        {
          id = 218,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/pineSapling.png",
          width = 70,
          height = 70
        },
        {
          id = 219,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/pineSaplingAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 220,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/plant.png",
          width = 70,
          height = 70
        },
        {
          id = 221,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/plantAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 222,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/rock.png",
          width = 70,
          height = 70
        },
        {
          id = 223,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/rockAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 224,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowBall.png",
          width = 70,
          height = 70
        },
        {
          id = 225,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowBallBig.png",
          width = 70,
          height = 70
        },
        {
          id = 226,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowBallBigGround.png",
          width = 70,
          height = 70
        },
        {
          id = 227,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowBallGround.png",
          width = 70,
          height = 70
        },
        {
          id = 228,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowGroundLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 229,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowGroundRight.png",
          width = 70,
          height = 70
        },
        {
          id = 230,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowHill.png",
          width = 70,
          height = 70
        },
        {
          id = 231,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowHillLow.png",
          width = 70,
          height = 70
        },
        {
          id = 232,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 233,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowMid.png",
          width = 70,
          height = 70
        },
        {
          id = 234,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowRight.png",
          width = 70,
          height = 70
        },
        {
          id = 235,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/snowWave.png",
          width = 70,
          height = 70
        },
        {
          id = 236,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikesBottom.png",
          width = 70,
          height = 70
        },
        {
          id = 237,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikesBottomAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 238,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikesBottomAlt2.png",
          width = 70,
          height = 70
        },
        {
          id = 239,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikesTop.png",
          width = 70,
          height = 70
        },
        {
          id = 240,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikesTopAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 241,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikesTopAlt2.png",
          width = 70,
          height = 70
        },
        {
          id = 242,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/spikeTop.png",
          width = 70,
          height = 70
        },
        {
          id = 243,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tree.png",
          width = 70,
          height = 70
        },
        {
          id = 244,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 245,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 246,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesLeftSnowAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 247,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesRight.png",
          width = 70,
          height = 70
        },
        {
          id = 248,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesSnowLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 249,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesSnowRight.png",
          width = 70,
          height = 70
        },
        {
          id = 250,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesSnowRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 251,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeBranchesSnowRightSnowAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 252,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTop.png",
          width = 70,
          height = 70
        },
        {
          id = 253,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTopSnow.png",
          width = 70,
          height = 70
        },
        {
          id = 254,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunk.png",
          width = 70,
          height = 70
        },
        {
          id = 255,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBottom.png",
          width = 70,
          height = 70
        },
        {
          id = 256,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBottomAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 257,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBottomAlt2.png",
          width = 70,
          height = 70
        },
        {
          id = 258,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBottomAlt3.png",
          width = 70,
          height = 70
        },
        {
          id = 259,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBranch.png",
          width = 70,
          height = 70
        },
        {
          id = 260,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBranchEndLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 261,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBranchEndRight.png",
          width = 70,
          height = 70
        },
        {
          id = 262,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBranchLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 263,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkBranchRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 264,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkSplitLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 265,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkSplitRight.png",
          width = 70,
          height = 70
        },
        {
          id = 266,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/treeTrunkTop.png",
          width = 70,
          height = 70
        },
        {
          id = 267,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundra.png",
          width = 70,
          height = 70
        },
        {
          id = 268,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 269,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 270,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 271,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 272,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 273,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 274,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 275,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 276,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 277,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 278,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 279,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 280,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 281,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 282,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraLedgeLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 283,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraLedgeRight.png",
          width = 70,
          height = 70
        },
        {
          id = 284,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 285,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraMid.png",
          width = 70,
          height = 70
        },
        {
          id = 286,
          image = "../sprites/Platformer Art Complete Pack/Ice expansion/Tiles/tundraRight.png",
          width = 70,
          height = 70
        }
      }
    },
    {
      name = "PT Candy",
      firstgid = 652,
      class = "",
      tilewidth = 70,
      tileheight = 70,
      spacing = 0,
      margin = 0,
      columns = 0,
      objectalignment = "unspecified",
      tilerendersize = "tile",
      fillmode = "stretch",
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      wangsets = {},
      tilecount = 95,
      tiles = {
        {
          id = 95,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cake.png",
          width = 70,
          height = 70
        },
        {
          id = 96,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 97,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 98,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 99,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 100,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 101,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 102,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 103,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 104,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfAltLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 105,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfAltMid.png",
          width = 70,
          height = 70
        },
        {
          id = 106,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfAltRight.png",
          width = 70,
          height = 70
        },
        {
          id = 107,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 108,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 109,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 110,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 111,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 112,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 113,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 114,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeLedgeLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 115,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeLedgeRight.png",
          width = 70,
          height = 70
        },
        {
          id = 116,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 117,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeMid.png",
          width = 70,
          height = 70
        },
        {
          id = 118,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cakeRight.png",
          width = 70,
          height = 70
        },
        {
          id = 119,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/candyBlue.png",
          width = 70,
          height = 70
        },
        {
          id = 120,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/candyGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 121,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/candyRed.png",
          width = 70,
          height = 70
        },
        {
          id = 122,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/candyYellow.png",
          width = 70,
          height = 70
        },
        {
          id = 123,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/canePink.png",
          width = 70,
          height = 70
        },
        {
          id = 124,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/canePinkSmall.png",
          width = 70,
          height = 70
        },
        {
          id = 125,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/canePinkTop.png",
          width = 70,
          height = 70
        },
        {
          id = 126,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/canePinkTopAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 127,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cherry.png",
          width = 70,
          height = 70
        },
        {
          id = 128,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/choco.png",
          width = 70,
          height = 70
        },
        {
          id = 129,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoCenter.png",
          width = 70,
          height = 70
        },
        {
          id = 130,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoCenter_rounded.png",
          width = 70,
          height = 70
        },
        {
          id = 131,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoCliffLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 132,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoCliffLeftAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 133,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoCliffRight.png",
          width = 70,
          height = 70
        },
        {
          id = 134,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoCliffRightAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 135,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalf.png",
          width = 70,
          height = 70
        },
        {
          id = 136,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 137,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfAltLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 138,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfAltMid.png",
          width = 70,
          height = 70
        },
        {
          id = 139,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfAltRight.png",
          width = 70,
          height = 70
        },
        {
          id = 140,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 141,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfMid.png",
          width = 70,
          height = 70
        },
        {
          id = 142,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHalfRight.png",
          width = 70,
          height = 70
        },
        {
          id = 143,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHillLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 144,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHillLeft2.png",
          width = 70,
          height = 70
        },
        {
          id = 145,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHillRight.png",
          width = 70,
          height = 70
        },
        {
          id = 146,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoHillRight2.png",
          width = 70,
          height = 70
        },
        {
          id = 147,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoLedgeLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 148,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoLedgeRight.png",
          width = 70,
          height = 70
        },
        {
          id = 149,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 150,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoMid.png",
          width = 70,
          height = 70
        },
        {
          id = 151,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/chocoRight.png",
          width = 70,
          height = 70
        },
        {
          id = 152,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cookieBrown.png",
          width = 70,
          height = 70
        },
        {
          id = 153,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cookieChoco.png",
          width = 70,
          height = 70
        },
        {
          id = 154,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cookiePink.png",
          width = 70,
          height = 70
        },
        {
          id = 155,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/creamChoco.png",
          width = 70,
          height = 70
        },
        {
          id = 156,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/creamMocca.png",
          width = 70,
          height = 70
        },
        {
          id = 157,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/creamPink.png",
          width = 70,
          height = 70
        },
        {
          id = 158,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/creamVanilla.png",
          width = 70,
          height = 70
        },
        {
          id = 159,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/cupCake.png",
          width = 70,
          height = 70
        },
        {
          id = 160,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/gummyWormGreenEnd.png",
          width = 70,
          height = 70
        },
        {
          id = 161,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/gummyWormGreenHead.png",
          width = 70,
          height = 70
        },
        {
          id = 162,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/gummyWormGreenMid.png",
          width = 70,
          height = 70
        },
        {
          id = 163,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/gummyWormRedEnd.png",
          width = 70,
          height = 70
        },
        {
          id = 164,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/gummyWormRedHead.png",
          width = 70,
          height = 70
        },
        {
          id = 165,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/gummyWormRedMid.png",
          width = 70,
          height = 70
        },
        {
          id = 166,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/heart.png",
          width = 70,
          height = 70
        },
        {
          id = 167,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCaneChoco.png",
          width = 70,
          height = 70
        },
        {
          id = 168,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCaneChocoTop.png",
          width = 70,
          height = 70
        },
        {
          id = 169,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCaneGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 170,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCaneGreenTop.png",
          width = 70,
          height = 70
        },
        {
          id = 171,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCanePink.png",
          width = 70,
          height = 70
        },
        {
          id = 172,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCanePinkTop.png",
          width = 70,
          height = 70
        },
        {
          id = 173,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCaneRed.png",
          width = 70,
          height = 70
        },
        {
          id = 174,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/hillCaneRedTop.png",
          width = 70,
          height = 70
        },
        {
          id = 175,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopBase.png",
          width = 70,
          height = 70
        },
        {
          id = 176,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopBaseBeige.png",
          width = 70,
          height = 70
        },
        {
          id = 177,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopBaseBrown.png",
          width = 70,
          height = 70
        },
        {
          id = 178,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopBaseCake.png",
          width = 70,
          height = 70
        },
        {
          id = 179,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopBasePink.png",
          width = 70,
          height = 70
        },
        {
          id = 180,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopFruitGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 181,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopFruitRed.png",
          width = 70,
          height = 70
        },
        {
          id = 182,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopFruitYellow.png",
          width = 70,
          height = 70
        },
        {
          id = 183,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 184,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopRed.png",
          width = 70,
          height = 70
        },
        {
          id = 185,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopWhiteGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 186,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/lollipopWhiteRed.png",
          width = 70,
          height = 70
        },
        {
          id = 187,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/waffleChoco.png",
          width = 70,
          height = 70
        },
        {
          id = 188,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/wafflePink.png",
          width = 70,
          height = 70
        },
        {
          id = 189,
          image = "../sprites/Platformer Art Complete Pack/Candy expansion/Tiles/waffleWhite.png",
          width = 70,
          height = 70
        }
      }
    },
    {
      name = "PT Buildings",
      firstgid = 842,
      class = "",
      tilewidth = 70,
      tileheight = 70,
      spacing = 0,
      margin = 0,
      columns = 0,
      objectalignment = "unspecified",
      tilerendersize = "tile",
      fillmode = "stretch",
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      wangsets = {},
      tilecount = 98,
      tiles = {
        {
          id = 98,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/anemometer.png",
          width = 70,
          height = 70
        },
        {
          id = 99,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/awningGreen.png",
          width = 70,
          height = 70
        },
        {
          id = 100,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/awningGreenRed.png",
          width = 70,
          height = 70
        },
        {
          id = 101,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/awningRed.png",
          width = 70,
          height = 70
        },
        {
          id = 102,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/chimney.png",
          width = 70,
          height = 70
        },
        {
          id = 103,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/chimneyLow.png",
          width = 70,
          height = 70
        },
        {
          id = 104,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/chimneyThin.png",
          width = 70,
          height = 70
        },
        {
          id = 105,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/clock.png",
          width = 70,
          height = 70
        },
        {
          id = 106,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorKnob.png",
          width = 70,
          height = 70
        },
        {
          id = 107,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorKnobAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 108,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorLock.png",
          width = 70,
          height = 70
        },
        {
          id = 109,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorOpen.png",
          width = 70,
          height = 70
        },
        {
          id = 110,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorOpenTop.png",
          width = 70,
          height = 70
        },
        {
          id = 111,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorPlateTop.png",
          width = 70,
          height = 70
        },
        {
          id = 112,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorTop.png",
          width = 70,
          height = 70
        },
        {
          id = 113,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/doorWindowTop.png",
          width = 70,
          height = 70
        },
        {
          id = 114,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/fenceGate.png",
          width = 70,
          height = 70
        },
        {
          id = 115,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/fenceLong.png",
          width = 70,
          height = 70
        },
        {
          id = 116,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/fenceLow.png",
          width = 70,
          height = 70
        },
        {
          id = 117,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeige.png",
          width = 70,
          height = 70
        },
        {
          id = 118,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 119,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeAlt2.png",
          width = 70,
          height = 70
        },
        {
          id = 120,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeBottomLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 121,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeBottomMid.png",
          width = 70,
          height = 70
        },
        {
          id = 122,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeBottomRight.png",
          width = 70,
          height = 70
        },
        {
          id = 123,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeMidLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 124,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeMidRight.png",
          width = 70,
          height = 70
        },
        {
          id = 125,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeTopLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 126,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeTopMid.png",
          width = 70,
          height = 70
        },
        {
          id = 127,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseBeigeTopRight.png",
          width = 70,
          height = 70
        },
        {
          id = 128,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDark.png",
          width = 70,
          height = 70
        },
        {
          id = 129,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 130,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkAlt2.png",
          width = 70,
          height = 70
        },
        {
          id = 131,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkBottomLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 132,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkBottomMid.png",
          width = 70,
          height = 70
        },
        {
          id = 133,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkBottomRight.png",
          width = 70,
          height = 70
        },
        {
          id = 134,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkMidLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 135,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkMidRight.png",
          width = 70,
          height = 70
        },
        {
          id = 136,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkTopLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 137,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkTopMid.png",
          width = 70,
          height = 70
        },
        {
          id = 138,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseDarkTopRight.png",
          width = 70,
          height = 70
        },
        {
          id = 139,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGray.png",
          width = 70,
          height = 70
        },
        {
          id = 140,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 141,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayAlt2.png",
          width = 70,
          height = 70
        },
        {
          id = 142,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayBottomLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 143,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayBottomMid.png",
          width = 70,
          height = 70
        },
        {
          id = 144,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayBottomRight.png",
          width = 70,
          height = 70
        },
        {
          id = 145,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayMidLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 146,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayMidRight.png",
          width = 70,
          height = 70
        },
        {
          id = 147,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayTopLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 148,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayTopMid.png",
          width = 70,
          height = 70
        },
        {
          id = 149,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/houseGrayTopRight.png",
          width = 70,
          height = 70
        },
        {
          id = 150,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/rockMoss.png",
          width = 70,
          height = 70
        },
        {
          id = 151,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/rockMossAlt.png",
          width = 70,
          height = 70
        },
        {
          id = 152,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofGreyLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 153,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofGreyMid.png",
          width = 70,
          height = 70
        },
        {
          id = 154,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofGreyRight.png",
          width = 70,
          height = 70
        },
        {
          id = 155,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofGreyTopLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 156,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofGreyTopMid.png",
          width = 70,
          height = 70
        },
        {
          id = 157,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofGreyTopRight.png",
          width = 70,
          height = 70
        },
        {
          id = 158,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofRedLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 159,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofRedMid.png",
          width = 70,
          height = 70
        },
        {
          id = 160,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofRedRight.png",
          width = 70,
          height = 70
        },
        {
          id = 161,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofRedTopLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 162,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofRedTopMid.png",
          width = 70,
          height = 70
        },
        {
          id = 163,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofRedTopRight.png",
          width = 70,
          height = 70
        },
        {
          id = 164,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofYellowLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 165,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofYellowMid.png",
          width = 70,
          height = 70
        },
        {
          id = 166,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofYellowRight.png",
          width = 70,
          height = 70
        },
        {
          id = 167,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofYellowTopLeft.png",
          width = 70,
          height = 70
        },
        {
          id = 168,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofYellowTopMid.png",
          width = 70,
          height = 70
        },
        {
          id = 169,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/roofYellowTopRight.png",
          width = 70,
          height = 70
        },
        {
          id = 170,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/signBed.png",
          width = 70,
          height = 70
        },
        {
          id = 171,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/signCoin.png",
          width = 70,
          height = 70
        },
        {
          id = 172,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/signCup.png",
          width = 70,
          height = 70
        },
        {
          id = 173,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/signHangingBed.png",
          width = 70,
          height = 70
        },
        {
          id = 174,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/signHangingCoin.png",
          width = 70,
          height = 70
        },
        {
          id = 175,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/signHangingCup.png",
          width = 70,
          height = 70
        },
        {
          id = 176,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/window.png",
          width = 70,
          height = 70
        },
        {
          id = 177,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowCheckered.png",
          width = 70,
          height = 70
        },
        {
          id = 178,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighBottom.png",
          width = 70,
          height = 70
        },
        {
          id = 179,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighCheckeredBottom.png",
          width = 70,
          height = 70
        },
        {
          id = 180,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighCheckeredMid.png",
          width = 70,
          height = 70
        },
        {
          id = 181,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighCheckeredTop.png",
          width = 70,
          height = 70
        },
        {
          id = 182,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighLeadlightBottom.png",
          width = 70,
          height = 70
        },
        {
          id = 183,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighLeadlightMid.png",
          width = 70,
          height = 70
        },
        {
          id = 184,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighLeadlightTop.png",
          width = 70,
          height = 70
        },
        {
          id = 185,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighMid.png",
          width = 70,
          height = 70
        },
        {
          id = 186,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighOpenBottom.png",
          width = 70,
          height = 70
        },
        {
          id = 187,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighOpenMid.png",
          width = 70,
          height = 70
        },
        {
          id = 188,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighOpenTop.png",
          width = 70,
          height = 70
        },
        {
          id = 189,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowHighTop.png",
          width = 70,
          height = 70
        },
        {
          id = 190,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowLeadlight.png",
          width = 70,
          height = 70
        },
        {
          id = 191,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowLow.png",
          width = 70,
          height = 70
        },
        {
          id = 192,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowLowCheckered.png",
          width = 70,
          height = 70
        },
        {
          id = 193,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowLowLeadlight.png",
          width = 70,
          height = 70
        },
        {
          id = 194,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowLowOpen.png",
          width = 70,
          height = 70
        },
        {
          id = 195,
          image = "../sprites/Platformer Art Complete Pack/Buildings expansion/Tiles/windowOpen.png",
          width = 70,
          height = 70
        }
      }
    },
    {
      name = "PT Enemies",
      firstgid = 1038,
      class = "",
      tilewidth = 88,
      tileheight = 147,
      spacing = 0,
      margin = 0,
      columns = 0,
      objectalignment = "unspecified",
      tilerendersize = "tile",
      fillmode = "stretch",
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      wangsets = {},
      tilecount = 118,
      tiles = {
        {
          id = 118,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/barnacle.png",
          width = 51,
          height = 57
        },
        {
          id = 119,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/barnacle_bite.png",
          width = 51,
          height = 58
        },
        {
          id = 120,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/barnacle_dead.png",
          width = 51,
          height = 57
        },
        {
          id = 121,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/barnacle_hit.png",
          width = 51,
          height = 57
        },
        {
          id = 122,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bat.png",
          width = 70,
          height = 47
        },
        {
          id = 123,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bat_dead.png",
          width = 70,
          height = 47
        },
        {
          id = 124,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bat_fly.png",
          width = 88,
          height = 37
        },
        {
          id = 125,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bat_hang.png",
          width = 38,
          height = 48
        },
        {
          id = 126,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bat_hit.png",
          width = 70,
          height = 47
        },
        {
          id = 127,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bee.png",
          width = 56,
          height = 48
        },
        {
          id = 128,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bee_dead.png",
          width = 56,
          height = 48
        },
        {
          id = 129,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bee_fly.png",
          width = 61,
          height = 42
        },
        {
          id = 130,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/bee_hit.png",
          width = 56,
          height = 48
        },
        {
          id = 131,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishGreen.png",
          width = 60,
          height = 45
        },
        {
          id = 132,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishGreen_dead.png",
          width = 60,
          height = 45
        },
        {
          id = 133,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishGreen_hit.png",
          width = 57,
          height = 44
        },
        {
          id = 134,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishGreen_swim.png",
          width = 57,
          height = 44
        },
        {
          id = 135,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishPink.png",
          width = 60,
          height = 45
        },
        {
          id = 136,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishPink_dead.png",
          width = 60,
          height = 45
        },
        {
          id = 137,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishPink_hit.png",
          width = 57,
          height = 44
        },
        {
          id = 138,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fishPink_swim.png",
          width = 57,
          height = 44
        },
        {
          id = 139,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fly.png",
          width = 57,
          height = 45
        },
        {
          id = 140,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fly_dead.png",
          width = 57,
          height = 45
        },
        {
          id = 141,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fly_fly.png",
          width = 65,
          height = 39
        },
        {
          id = 142,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/fly_hit.png",
          width = 57,
          height = 45
        },
        {
          id = 143,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/frog.png",
          width = 58,
          height = 39
        },
        {
          id = 144,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/frog_dead.png",
          width = 61,
          height = 54
        },
        {
          id = 145,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/frog_hit.png",
          width = 61,
          height = 54
        },
        {
          id = 146,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/frog_leap.png",
          width = 61,
          height = 54
        },
        {
          id = 147,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ghost.png",
          width = 51,
          height = 73
        },
        {
          id = 148,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ghost_dead.png",
          width = 51,
          height = 73
        },
        {
          id = 149,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ghost_hit.png",
          width = 51,
          height = 73
        },
        {
          id = 150,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ghost_normal.png",
          width = 51,
          height = 73
        },
        {
          id = 151,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/grassBlock.png",
          width = 71,
          height = 70
        },
        {
          id = 152,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/grassBlock_dead.png",
          width = 71,
          height = 70
        },
        {
          id = 153,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/grassBlock_hit.png",
          width = 71,
          height = 70
        },
        {
          id = 154,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/grassBlock_jump.png",
          width = 71,
          height = 70
        },
        {
          id = 155,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ladyBug.png",
          width = 58,
          height = 34
        },
        {
          id = 156,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ladyBug_fly.png",
          width = 59,
          height = 42
        },
        {
          id = 157,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ladyBug_hit.png",
          width = 58,
          height = 34
        },
        {
          id = 158,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/ladyBug_walk.png",
          width = 61,
          height = 34
        },
        {
          id = 159,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/mouse.png",
          width = 59,
          height = 35
        },
        {
          id = 160,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/mouse_dead.png",
          width = 59,
          height = 35
        },
        {
          id = 161,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/mouse_hit.png",
          width = 59,
          height = 35
        },
        {
          id = 162,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/mouse_walk.png",
          width = 58,
          height = 35
        },
        {
          id = 163,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/piranha.png",
          width = 45,
          height = 60
        },
        {
          id = 164,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/piranha_dead.png",
          width = 45,
          height = 60
        },
        {
          id = 165,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/piranha_down.png",
          width = 45,
          height = 60
        },
        {
          id = 166,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/piranha_hit.png",
          width = 45,
          height = 60
        },
        {
          id = 167,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slime.png",
          width = 49,
          height = 34
        },
        {
          id = 168,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slime_dead.png",
          width = 49,
          height = 34
        },
        {
          id = 169,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slime_hit.png",
          width = 49,
          height = 34
        },
        {
          id = 170,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slime_squashed.png",
          width = 57,
          height = 13
        },
        {
          id = 171,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slime_walk.png",
          width = 57,
          height = 30
        },
        {
          id = 172,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlock.png",
          width = 51,
          height = 50
        },
        {
          id = 173,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlock_dead.png",
          width = 51,
          height = 50
        },
        {
          id = 174,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlock_hit.png",
          width = 51,
          height = 50
        },
        {
          id = 175,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlue.png",
          width = 49,
          height = 34
        },
        {
          id = 176,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlue_blue.png",
          width = 57,
          height = 30
        },
        {
          id = 177,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlue_dead.png",
          width = 49,
          height = 34
        },
        {
          id = 178,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlue_hit.png",
          width = 49,
          height = 34
        },
        {
          id = 179,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeBlue_squashed.png",
          width = 57,
          height = 13
        },
        {
          id = 180,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeGreen.png",
          width = 49,
          height = 34
        },
        {
          id = 181,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeGreen_dead.png",
          width = 49,
          height = 34
        },
        {
          id = 182,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeGreen_hit.png",
          width = 49,
          height = 34
        },
        {
          id = 183,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeGreen_squashed.png",
          width = 57,
          height = 13
        },
        {
          id = 184,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/slimeGreen_walk.png",
          width = 57,
          height = 30
        },
        {
          id = 185,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snail.png",
          width = 55,
          height = 40
        },
        {
          id = 186,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snail_hit.png",
          width = 55,
          height = 40
        },
        {
          id = 187,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snail_shell.png",
          width = 43,
          height = 35
        },
        {
          id = 188,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snail_walk.png",
          width = 60,
          height = 40
        },
        {
          id = 189,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snake.png",
          width = 63,
          height = 23
        },
        {
          id = 190,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snake_dead.png",
          width = 63,
          height = 23
        },
        {
          id = 191,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snake_hit.png",
          width = 63,
          height = 23
        },
        {
          id = 192,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snake_walk.png",
          width = 63,
          height = 23
        },
        {
          id = 193,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeLava.png",
          width = 53,
          height = 147
        },
        {
          id = 194,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeLava_ani.png",
          width = 52,
          height = 147
        },
        {
          id = 195,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeLava_dead.png",
          width = 53,
          height = 147
        },
        {
          id = 196,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeLava_hit.png",
          width = 53,
          height = 147
        },
        {
          id = 197,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeSlime.png",
          width = 53,
          height = 147
        },
        {
          id = 198,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeSlime_ani.png",
          width = 52,
          height = 147
        },
        {
          id = 199,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeSlime_dead.png",
          width = 53,
          height = 147
        },
        {
          id = 200,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/snakeSlime_hit.png",
          width = 53,
          height = 147
        },
        {
          id = 201,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spider.png",
          width = 71,
          height = 45
        },
        {
          id = 202,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spider_dead.png",
          width = 69,
          height = 51
        },
        {
          id = 203,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spider_hit.png",
          width = 71,
          height = 45
        },
        {
          id = 204,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spider_walk1.png",
          width = 72,
          height = 51
        },
        {
          id = 205,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spider_walk2.png",
          width = 77,
          height = 53
        },
        {
          id = 206,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinner.png",
          width = 63,
          height = 62
        },
        {
          id = 207,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinner_dead.png",
          width = 63,
          height = 62
        },
        {
          id = 208,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinner_hit.png",
          width = 61,
          height = 61
        },
        {
          id = 209,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinner_spin.png",
          width = 61,
          height = 61
        },
        {
          id = 210,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinnerHalf.png",
          width = 63,
          height = 31
        },
        {
          id = 211,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinnerHalf_dead.png",
          width = 63,
          height = 31
        },
        {
          id = 212,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinnerHalf_hit.png",
          width = 61,
          height = 30
        },
        {
          id = 213,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/spinnerHalf_spin.png",
          width = 61,
          height = 30
        },
        {
          id = 214,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/worm.png",
          width = 63,
          height = 23
        },
        {
          id = 215,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/worm_dead.png",
          width = 63,
          height = 23
        },
        {
          id = 216,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/worm_hit.png",
          width = 63,
          height = 23
        },
        {
          id = 217,
          image = "../sprites/Platformer Art Complete Pack/Extra animations and enemies/Enemy sprites/worm_walk.png",
          width = 63,
          height = 23
        },
        {
          id = 218,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/blockerBody.png",
          width = 51,
          height = 51
        },
        {
          id = 219,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/blockerMad.png",
          width = 51,
          height = 51
        },
        {
          id = 220,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/blockerSad.png",
          width = 51,
          height = 51
        },
        {
          id = 221,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/fishDead.png",
          width = 66,
          height = 42
        },
        {
          id = 222,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/fishSwim1.png",
          width = 66,
          height = 42
        },
        {
          id = 223,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/fishSwim2.png",
          width = 62,
          height = 43
        },
        {
          id = 224,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/flyDead.png",
          width = 59,
          height = 33
        },
        {
          id = 225,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/flyFly1.png",
          width = 72,
          height = 36
        },
        {
          id = 226,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/flyFly2.png",
          width = 75,
          height = 31
        },
        {
          id = 227,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/pokerMad.png",
          width = 48,
          height = 146
        },
        {
          id = 228,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/pokerSad.png",
          width = 48,
          height = 146
        },
        {
          id = 229,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/slimeDead.png",
          width = 59,
          height = 12
        },
        {
          id = 230,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/slimeWalk1.png",
          width = 50,
          height = 28
        },
        {
          id = 231,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/slimeWalk2.png",
          width = 51,
          height = 26
        },
        {
          id = 232,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/snailShell.png",
          width = 44,
          height = 30
        },
        {
          id = 233,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/snailShell_upsidedown.png",
          width = 44,
          height = 30
        },
        {
          id = 234,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/snailWalk1.png",
          width = 54,
          height = 31
        },
        {
          id = 235,
          image = "../sprites/Platformer Art Complete Pack/Base pack/Enemies/snailWalk2.png",
          width = 57,
          height = 31
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      x = 0,
      y = 0,
      width = 100,
      height = 30,
      id = 1,
      name = "Ground",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 68, 83, 83, 83, 83, 83, 83, 83, 83, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 83, 83, 83, 83, 83, 70, 0, 0, 0, 0, 0, 73, 74, 74, 74, 74, 74, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 83, 83, 83, 83, 83, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 83, 83, 83, 83, 83, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 83, 83, 83, 83, 83, 83, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 74, 74, 74, 74, 74, 74, 74, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 83, 83, 83, 83, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 82, 84, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 74, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 73, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 83, 83, 83, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 74, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 83, 83, 83, 83, 83, 83, 83, 78, 0, 0, 0, 0, 0, 0, 0, 82, 83, 84, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 83, 83, 83, 83, 83, 83, 83, 77, 66, 66, 66, 66, 66, 66, 66, 79, 78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 77, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 79, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 74, 74, 74, 74, 74, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 77, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 77, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 83, 83, 83, 83, 83, 78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 77, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 83, 78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        82, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 77, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 0, 0, 83, 83, 83, 0, 0, 83, 83, 83, 83, 78, 0, 0, 0, 0, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 84,
        66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 0, 0, 66, 66, 66, 0, 0, 66, 66, 66, 66, 79, 78, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 66, 66, 66, 66, 66, 66, 66,
        66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 0, 0, 66, 66, 66, 0, 0, 66, 66, 66, 66, 66, 79, 78, 0, 0, 0, 0, 0, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 0, 0, 66, 66, 66, 66, 66, 66, 66,
        66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 0, 0, 66, 66, 66, 0, 0, 66, 66, 66, 66, 66, 66, 79, 83, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 83, 83, 83, 83, 83, 66, 66, 66, 66, 66, 66, 66,
        66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66, 66
      }
    },
    {
      type = "tilelayer",
      x = 0,
      y = 0,
      width = 100,
      height = 30,
      id = 3,
      name = "Plants",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 293, 293, 293, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 249, 293, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 249, 293, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 293, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 293, 249, 0, 0, 249, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 249, 0, 293, 0, 249, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 293, 293, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 293, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 293, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 293, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 249, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 293, 249, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 249, 249, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        293, 249, 0, 0, 0, 293, 293, 249, 249, 0, 0, 249, 0, 249, 293, 0, 293, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 293, 293, 293, 293, 0, 0, 0, 0, 0, 293, 0, 0, 0, 249, 249, 0, 0, 0, 293, 0, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 249, 0, 293, 0, 293, 249, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 249, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      x = 0,
      y = 0,
      width = 100,
      height = 30,
      id = 5,
      name = "Enemies",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      x = 0,
      y = 0,
      width = 100,
      height = 30,
      id = 4,
      name = "Collectables",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 264, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 264, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 264, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 263, 263, 263, 263, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 263, 0, 263, 0, 263, 0, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      x = 0,
      y = 0,
      width = 100,
      height = 30,
      id = 2,
      name = "Objects",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 262, 0, 0, 0, 7, 3, 11, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 262, 0, 0, 0, 0, 0, 261, 261, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 262, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 261, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 90, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 261, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 90, 90, 0, 0, 0, 261, 261, 0, 90, 90, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 262, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 262, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 262, 261, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 262, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 90, 90, 90, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 262, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 262, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 261, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 0, 90, 90, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 2, 7, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 275, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 299, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 129, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 129, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 90, 90, 90, 90, 90, 90, 90, 90, 127, 90, 90,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 169, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 252, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 297, 297, 0, 0, 0, 297, 297, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    }
  }
}
